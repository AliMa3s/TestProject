CREATE DATABASE  IF NOT EXISTS `webshop` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `webshop`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: webshop
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `street` varchar(255) NOT NULL,
  `number` int NOT NULL,
  `postalCode` varchar(50) NOT NULL,
  `city` varchar(100) NOT NULL,
  `telephoneNumber` varchar(20) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `totalPrice` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (23,'2020-12-29 10:40:51','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',224.99),(24,'2020-12-29 10:41:01','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',18045),(25,'2020-12-29 10:41:15','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',18045),(26,'2020-12-29 10:41:31','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',18045),(27,'2020-12-29 10:44:46','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',224.99),(28,'2020-12-29 10:44:54','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',18045),(29,'2020-12-29 10:45:21','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',18045),(30,'2020-12-29 10:45:52','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',224.99),(31,'2020-12-29 10:46:10','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',224.99),(32,'2020-12-30 12:04:47','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',237.13),(33,'2020-12-30 12:12:01','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',237.13),(34,'2020-12-30 12:12:47','Ali','maes','gentstraat',891480854,'9000','Gent','047111222','azdefatrhtws@gmail.com',237.13),(35,'2020-12-30 12:21:42','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',237.13),(36,'2020-12-30 12:22:14','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',237.13),(37,'2020-12-30 12:22:34','Ali','maes','gentstraat',891480854,'9000','Gent','047111222','azdefatrhtws@gmail.com',237.13),(38,'2020-12-30 12:24:34','Ali','maes','gentstraat',2469,'9000','Gent','047111222','azdefatrhtws@gmail.com',237.13),(39,'2020-12-30 13:00:40','Ali','maes','gentstraat',61,'9000','Gent','047111222','aaron.frans@student.howest.be',60.01),(40,'2020-12-31 14:10:59','Ali','maes','gentstraat',61,'9000','Gent','047111222','azdefatrhtws@gmail.com',64);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-06 13:03:07
