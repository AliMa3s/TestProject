import { createSlice } from '@reduxjs/toolkit';

const inventorySlice = createSlice({
    name: 'inventory',
    initialState: [],
    reducers: {
        addToInventory: (state, action) => { state.push(action.payload) },
        removeFromInventory: (state, action) => { state.pop()}
    }
})

export const {actions, reducer} = inventorySlice;
export const { addToInventory, removeFromInventory} = actions;