import './App.css';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import { useState, useEffect} from 'react';
import axios from "axios";
//---------------Own components-----------------------------
import NavigationBar from './components/Navbar';
import Footer from './components/Footer';
import BasketPage from './components/Basket/BasketPage';
import ProductPage from './components/Products/ProductPage';
import HomePage from './components/Home/HomePage';
//---------------Own components-----------------------------



const technologie =[{id: 1, name: 'Voorbeeld (via Express Server)'}]

const App=()=> {
  const student = {
    naam: "Ali Maes",
    StudNr: "077110am"
  }

  const [movies, setMovies] = useState(null);


  const fetchMovies = async ()=> {
    await axios.get("http://localhost:3000/movies")
    .then((response) => setMovies(response.data));
  }
  useEffect(()=> {
    fetchMovies();
  }, [])

  return (
      <Router>
    <div className="App">
      <NavigationBar/>
        <Routes>
        <Route path="/basket" element={<BasketPage />} />
          <Route path="/products" element={<ProductPage movies = {movies} />} />
          <Route path="/" element={<HomePage items={technologie}/>}>

          </Route>
        </Routes>
        <Footer naam={student.naam} studentNr={student.StudNr}/>
    </div>
      </Router>
  );
}

export default App;
