import React from 'react';
import ListItem from './ListItem';

const HomePage = (props) => {
    const {items} = props;

    return (
        <div className="HomePage">
            <h1>Welkom bij Ali's Webshop</h1>
            <p>Hier een lijst</p>
            <ul>
                <ListItem items={items}/>
            </ul>
        </div>
    )
}

export default HomePage;
