import React from 'react'
import Product from './Product';
import { Card } from 'react-bootstrap';
const ProductPage = (props) => {
    const { movies } = props;
    return (
        <div className="ProductPage">
            <h1>ProductPage</h1>
            <Card>
            {movies.map(Product)}
            </Card>
        </div>
    )
}

export default ProductPage
